<?php
/**
 *
 * ------------------------------------------------------------------------------
 * @category     AM
 * @package      AM_Export
 * ------------------------------------------------------------------------------
 * @copyright    Copyright (C) 2013 ArexMage.com. All Rights Reserved.
 * @license      GNU General Public License version 2 or later;
 * @author       ArexMage.com
 * @email        support@arexmage.com
 * ------------------------------------------------------------------------------
 *
 */
?>
<?php
class AM_Export_Helper_Data extends Mage_Core_Helper_Abstract
{
}