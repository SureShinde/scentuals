<?php

/**
 * Block of links in Order view page
 *
 * @category    Collinsharper
 * @package     Collinsharper_Canpost
 * @author      Maxim Nulman
 */
class Collinsharper_Canpost_Block_Google_Office_Map extends Mage_Core_Block_Template
{
    
    
    
}
