<?php

/** 
 *
 * @category    Collinsharper
 * @package     Collinsharper_Canpost
 * @author      Maxim Nulman
 */
class Collinsharper_Canpost_Model_Adminhtml_Quotetype extends Mage_Core_Model_Config_Data
{

    public function save()
    {

        return parent::save(); 
        
    }

}
