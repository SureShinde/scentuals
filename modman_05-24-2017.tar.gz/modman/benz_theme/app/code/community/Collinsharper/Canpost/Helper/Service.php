<?php
/** 
 *
 * @category    Collinsharper
 * @package     Collinsharper_Canpost
 * @author      Maxim Nulman
 * 
 * @deprecated
 */
class Collinsharper_Canpost_Helper_Service extends Mage_Core_Helper_Abstract
{
    /**
     * @deprecated
     */
    public function ajustRates($services)
    {
        
        //foreach ($services as $service) {
        //    
        //    $info = Mage::helper('chcanpost2module/rest_service')->getInfo($service_code, $country_code);
        //    
        //}
        
    }
    
}
