<?php
/**
 * 
 * @package Collinsharper_Canpost
 *
 * @author Maxim Nulman 
 */
class Collinsharper_Canpost_Block_Adminhtml_Sales_Order_Shipment_Create extends Mage_Adminhtml_Block_Sales_Order_Shipment_Create
{

}
